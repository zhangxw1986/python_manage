import os
print(os.path.abspath(__file__))
print(__file__)
